package com.example.jaimearturo.mascotas;

/**
 * Created by JaimeArturo on 10/06/2017.
 */

public class Mascota {
    private int fotoMascota;
    private String nombreMascota;
    private String likeMascota;

    public Mascota(int fotoMascota, String nombreMascota, String likeMascota) {
        this.fotoMascota = fotoMascota;
        this.nombreMascota = nombreMascota;
        this.likeMascota = likeMascota;
    }

    public int getFotoMascota() {
        return fotoMascota;
    }

    public void setFotoMascota(int fotoMascota) {
        this.fotoMascota = fotoMascota;
    }

    public String getNombreMascota() {
        return nombreMascota;
    }

    public void setNombreMascota(String nombreMascota) {
        this.nombreMascota = nombreMascota;
    }

    public String getLikeMascota() {
        return likeMascota;
    }

    public void setLikeMascota(String likeMascota) {
        this.likeMascota = likeMascota;
    }
}
